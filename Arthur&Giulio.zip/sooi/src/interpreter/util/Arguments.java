package interpreter.util;

public class Arguments extends Instance {
}
